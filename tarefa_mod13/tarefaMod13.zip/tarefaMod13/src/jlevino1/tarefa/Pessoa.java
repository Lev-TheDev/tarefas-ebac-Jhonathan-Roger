package jlevino1.tarefa;

public abstract class Pessoa {

    private String nome;

    private String tipoConta;

    private String banco;
}
