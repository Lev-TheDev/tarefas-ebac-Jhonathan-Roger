package jlevino1.tarefa;

public class PessoaJuridica extends Pessoa {

    private Long cnpj;

}
