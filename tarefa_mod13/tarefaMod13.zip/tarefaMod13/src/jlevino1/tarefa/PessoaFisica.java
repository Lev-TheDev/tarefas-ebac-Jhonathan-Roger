package jlevino1.tarefa;

public class PessoaFisica extends Pessoa {

    private Long cpf;

}
