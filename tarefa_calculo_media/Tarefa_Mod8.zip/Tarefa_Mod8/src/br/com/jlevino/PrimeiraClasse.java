package br.com.jlevino;

public class PrimeiraClasse {
}
