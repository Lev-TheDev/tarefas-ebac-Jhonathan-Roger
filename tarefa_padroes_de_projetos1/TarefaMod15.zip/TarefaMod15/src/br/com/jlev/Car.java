package br.com.jlev;

public abstract class Car {
    public String model;
    public int horsepower;
}
