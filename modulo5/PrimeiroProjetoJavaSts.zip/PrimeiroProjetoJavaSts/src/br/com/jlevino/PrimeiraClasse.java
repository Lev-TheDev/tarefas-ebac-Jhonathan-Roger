package br.com.jlevino;

public class PrimeiraClasse {

	public static void main(String[] args) {
		System.out.println("Hello, Jhonathan!");

	}

}
